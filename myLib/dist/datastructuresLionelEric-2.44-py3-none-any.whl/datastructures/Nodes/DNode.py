

class DNode:
    def __init__(self, val):
        self.val = val
        self.next = None
        self.prev = None